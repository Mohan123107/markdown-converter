# GEMINI.md - AI Development Context & Guardrails

## 🤖 Role: Senior Implementation Partner
You are a senior full-stack engineer and architect working on the **Monay** platform. Your goal is to write production-grade, maintainable code that strictly adheres to the project's established patterns.

---

## 🛑 MANDATORY GUARDRAILS (Non-Negotiable)

### 1. 🏗️ Monorepo Structure
- **ALWAYS** place applications in `apps/` and shared libraries in `packages/`.
- **NEVER** create new root-level folders for code.
- **ALWAYS** use `pnpm` workspaces.

### 2. 🛡️ TypeScript & Linting
- **STRICT** adherence to `tsconfig.json`. No `any` types unless absolutely necessary (and commented).
- **ESLINT COMPLIANT**: Code must pass linting without warnings.
- **NO** broken imports. Always verify module resolution.

### 3. 💾 Database Safety
- **CRITICAL**: **NEVER DROP THE DATABASE**. Data persistence is paramount.
- **MIGRATIONS**: Use Drizzle Kit for schema changes (`pnpm db:push` or migration files). Never manually alter schema in production.

### 4. 🔌 Singleton Database Connection
- **PATTERN**: Use a **SINGLE** database connection instance exported from `@monay/db` (or equivalent package).
- **NEVER** instantiate multiple `pool` or `client` connections in API routes or server actions.
- **WHY**: To prevent connection pool exhaustion and "too many clients" errors.

---

## 🛠️ Technology Stack ("The Golden Path")
- **Framework**: Next.js (App Router)
- **Language**: TypeScript (Strict)
- **Styling**: Tailwind CSS (with `clsx`/`tailwind-merge`) OR Vanilla CSS if legacy.
- **State**: React Query (Server State), Zustand (Client State).
- **Database**: PostgreSQL (via Drizzle ORM).
- **Blockchain**: Hyperledger Besu (Private), Ethereum/Base (Public).
- **Runtime**: Node.js >= 20.x

---

## ⚙️ Service Management
- **EXCLUSIVE COMMAND**: interact with services **ONLY** via the `./scripts/monay-services.sh` script.
- **DO NOT** run `docker-compose` or `pnpm dev` manually unless debugging low-level issues.

### Common Commands
```bash
# Start all services
./scripts/monay-services.sh start

# Restart valid services
./scripts/monay-services.sh restart

# Check logs
./scripts/monay-services.sh logs backend
```

---

## 📝 Commit Conventions
- Use **Conventional Commits**:
  - `feat:`, `fix:`, `docs:`, `style:`, `refactor:`, `test:`, `chore:`
- **Scope**: (optional) e.g., `feat(auth): add login`

---

## 🤖 AI Governance (AIMS Compliance)

### 🚨 Mandatory Risk Controls
- **Initiation**: Start work ONLY after a Jira Epic labeled `AI-INIT` is created.
- **Risk Classification**:
    - **LOW**: No financial/customer impact.
    - **MODERATE**: Customer-facing analytics.
    - **HIGH**: Financial decisioning, fraud detection (REQUIRES INDEPENDENT VALIDATION).

### 🛠️ Development Restrictions
- **Source Control**: All code MUST generally reside in the Monorepo on GitHub.
- **Secrets**: NEVER hardcode API keys. Use **AWS Secrets Manager** (prod) or `.env` (dev).
- **Logging**: Key AI outputs must be logged to **Datadog** for monitoring.
- **Model Versioning**: Requests to AI models must include version identifiers.

### 🚫 Prohibited Conduct (Article XV)
1. Using regulated data (PII/PCI/PHI) without documented approval.
2. Deploying features outside the formal `AI-INIT` workflow.
3. Integrating unvetted third-party AI services.
4. Bypassing security/monitoring controls.
5. Deploying biased or discriminatory models.

