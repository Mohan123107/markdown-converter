# [Project Name]

[Brief description of what this project/module does and its role in the ecosystem.]

## 🚀 Quick Start

### Prerequisites
- Node.js >= 20.x
- pnpm >= 9.x
- Docker (for database)

### Installation
```bash
pnpm install
```

### Running Locally
```bash
# Start development server
pnpm dev

# Run tests
pnpm test
```

## 🏗️ Architecture

### Directory Structure
```
src/
├── app/            # Next.js App Router (if applicable)
├── components/     # React components
├── lib/            # Shared utilities
├── server/         # Server actions/API routes
└── types/          # TypeScript definitions
```

## 🔌 Integration

### API Ports (Avoid Conflicts!)
- **3001**: Main Backend API
- **3002**: Admin Dashboard
- **3003**: Consumer Wallet
- **3007**: Enterprise Wallet

## 🧪 Testing
- **Unit**: `pnpm test` (Vitest/Jest)
- **E2E**: `pnpm test:e2e` (Playwright)

## 🤝 Contributing
1. Create a feature branch (`feat/amazing-feature`).
2. Commit changes using Conventional Commits.
3. Push and open a PR.
4. Ensure CI passes (Linting, Types, Tests).

## ⚖️ Governance & Compliance
This project enforces the **AIMS-001 Artificial Intelligence Governance Policy**.
All contributors must read and acknowledge:
- [AIMS Manual](./AIMS_MANUAL.md) - Full Policy & Procedures
- [GEMINI.md](./GEMINI.md) - Developer Guardrails

**Key Requirement**: All AI-related changes require a Jira ticket labeled `AI-CHANGE`.

