# Skill.md — Tilli Software AI Development Competency Framework

> **Document ID**: AIMS-SKILL-001
> **Alignment**: AIMS-001 (AI Governance Policy), AIP-PR-001 (Procedure Manual)
> **Organization**: Tilli Software
> **Owner**: CTO (Operational) / AI Governance Lead (Oversight)
> **Applies To**: Engineering, Product, Security, Compliance, Data, Operations
> **Review Cycle**: Quarterly
> **Reviewer**: Raja Vemuri

> **Purpose**: This document defines the team's expected skill areas, competency levels, and
> training paths for working effectively with AI-assisted development tools within Tilli Software's
> governed engineering environment. It operationalizes the AIMS roles and accountability structure
> (AIMS-001, Article IV) and developer attestation requirements (AIP-PR-001, Section 5).

---

## AIMS Role Mapping (Article IV, Section 4.2)

Every team member must understand how their role maps to the AI Governance structure:

| AIMS Role | Responsibility | Skills Required |
|-----------|---------------|-----------------|
| **AI Governance Lead** | Oversight of AI risk management, compliance alignment, policy enforcement | Risk assessment, ISO 42001 awareness, audit readiness |
| **Engineering Lead** | Technical implementation, controls, system integrity | TypeScript, ORM, monorepo, CI/CD, security |
| **Product Owner** | Business justification, feature approval, lifecycle oversight | AI intake process, risk classification, documentation |
| **Security Team** | Security review, data protection validation | OWASP, secrets management, access control |
| **Compliance / Legal** | Regulatory assessment and risk advisory | Data classification (PCI/PII/PHI), jurisdiction awareness |

**No AI-enabled feature may be released to production without documented risk ownership and assigned accountability.**

---

## Core Competency Areas

### 1. TypeScript & ESLint Mastery

> **AIMS Reference**: Article V §3.5 (Security and Data Protection), AIP-PR-001 Stage 4

| Skill | Junior | Mid | Senior |
|-------|--------|-----|--------|
| Strict-mode TypeScript | Can read typed code | Writes typed code with generics | Designs type systems, utility types |
| ESLint configuration | Follows existing rules | Adds custom rules | Architects flat-config ESLint setups |
| No-`any` discipline | Understands why | Rarely uses `any` | Eliminates `any` across codebase |
| ES Module system | Uses import/export | Understands `.mjs`/`.cjs` | Configures module resolution |

**Key Lesson from Production:**
> TypeScript strict mode + `@typescript-eslint/strict` caught dozens of bugs before they reached production. The initial investment in strict config pays for itself within the first sprint.

**Required Knowledge:**
- Difference between `type` and `interface` and when to use each
- Generic constraints and conditional types
- Module resolution (`moduleResolution: "bundler"` vs `"node"`)
- Path aliases (`@/` imports) and their tsconfig mapping
- Why CommonJS (`require`) is banned and how to handle config-file exceptions (`.cjs`)

---

### 2. Monorepo Architecture (pnpm + Turborepo)

> **AIMS Reference**: Article VIII (Documentation and Traceability), AIP-PR-001 Stage 4

| Skill | Junior | Mid | Senior |
|-------|--------|-----|--------|
| Workspace navigation | Finds files across apps | Understands dependency graph | Designs package boundaries |
| Module isolation | Doesn't cross-import | Enforces via ESLint | Architects shared packages |
| Build pipelines | Runs `turbo build` | Configures `turbo.json` tasks | Optimizes caching strategies |
| Dependency management | Runs `pnpm install` | Manages workspace versions | Handles peer dependency conflicts |

**Key Lesson from Production:**
> Apps importing directly from other apps caused cascading build failures and circular dependencies. Enforcing module isolation via ESLint (`no-restricted-imports`) eliminated an entire class of build bugs.

**Required Knowledge:**
- `pnpm-workspace.yaml` syntax and filtering (`pnpm --filter @tilli/app`)
- Turborepo task dependencies (`dependsOn: ["^build"]`)
- When to create a new shared package vs keeping code in an app
- Scoped package naming (`@tilli/package-name`)
- Standard Tilli monorepo structure (`apps/`, `packages/`, `docs/`, `scripts/`)

**Tilli Standard Structure:**
```
TilliBeacon/          (or any Tilli product)
├── apps/
│   ├── api/
│   ├── web/
│   └── admin-portal/
├── packages/
│   ├── db/
│   ├── sdk/
│   ├── shared/
│   └── ui/
├── docs/
├── scripts/
└── CLAUDE.md
```

---

### 3. Database Management & ORM

> **AIMS Reference**: Article V §3.5, Article XII (Change Management), AIP-PR-001 Stage 4

| Skill | Junior | Mid | Senior |
|-------|--------|-----|--------|
| ORM queries (Drizzle) | Writes basic CRUD | Complex joins, subqueries | Query optimization, indexing strategy |
| Schema design | Follows existing patterns | Designs new tables | Architects multi-database systems |
| Migrations | Runs existing migrations | Writes safe, additive migrations | Plans zero-downtime schema changes |
| Connection management | Uses shared `@tilli/db` client | Understands pool tuning | Monitors connection health |

**Key Lessons from Production:**

> **Single Connection Pool**: Creating `new Pool()` in route files caused connection exhaustion under load. All database access MUST go through the single shared client exported from `@tilli/db`.

> **Never Drop Database**: A `DROP TABLE` in staging destroyed a week of QA test data. Migrations must be additive-only. Removals require a multi-step deprecation process.

> **ORM-Only Policy**: Raw SQL strings bypassed type safety and introduced SQL injection risk. Drizzle ORM must be used for all queries. Exception: performance-critical queries with parameterized SQL, reviewed in PR.

**Required Knowledge:**
- Drizzle ORM schema definition and query builder
- Migration workflow: `drizzle-kit generate` → review → `drizzle-kit push` (dev) / `migrate` (prod)
- Connection pool configuration (`max`, `idleTimeout`, `connectionString`)
- Why snake_case in DB and camelCase in TypeScript, and how Drizzle maps them
- PostgreSQL 16 features relevant to Tilli products

---

### 4. Authentication & Authorization

> **AIMS Reference**: Article V §3.4 (Human Oversight), §3.5 (Security), AIP-PR-001 Stage 4

| Skill | Junior | Mid | Senior |
|-------|--------|-----|--------|
| JWT handling | Uses auth context | Implements auth guards | Designs token refresh strategies |
| CBAC / RBAC | Understands capabilities | Implements capability checks | Designs access control systems |
| API contract stability | Follows existing contracts | Maintains backward compatibility | Versions APIs gracefully |
| Session management | Uses provided hooks | Configures session stores (Redis) | Implements secure session binding |

**Key Lesson from Production:**
> Changing the `/api/auth/me` response shape broke all three frontends simultaneously. Authentication endpoints are **system contracts** — they must never change without updating every consumer in the same commit.

**Required Knowledge:**
- JWT structure (header, payload, signature) and verification
- httpOnly cookie-based auth vs Bearer token auth
- Capability-based access control: `{domain}.{action}` naming convention
- Auth guard patterns for React/Next.js (`useAuth` hook + `useEffect` redirect)
- Why 401 (not 500) must be returned for invalid tokens

---

### 5. Service Management & DevOps

> **AIMS Reference**: AIP-PR-001 Stages 6–7 (Deployment & Monitoring)

| Skill | Junior | Mid | Senior |
|-------|--------|-----|--------|
| Local services | Starts/stops with script | Debugs port conflicts | Designs service orchestration |
| Docker | Runs `docker-compose up` | Writes Dockerfiles | Optimizes multi-stage builds |
| CI/CD (GitHub Actions) | Reads pipeline output | Fixes CI failures | Designs pipeline architecture |
| Monitoring (Datadog) | Reads dashboards | Configures alerts | Designs observability strategy |

**Key Lesson from Production:**
> Manual `pnpm dev` left zombie processes that consumed ports and file descriptors, eventually crashing the dev machine with "EMFILE: too many open files." A centralized service script with PID tracking eliminated the problem entirely.

**Required Knowledge:**
- Service dependency order (DB → Backend → Frontend apps)
- Port management and conflict resolution
- Docker Compose for local database and infrastructure services
- GitHub Actions OIDC authentication (no long-lived AWS credentials)
- AWS ECS / ECR deployment workflow
- Datadog dashboard creation and alerting
- Health check endpoints and how to verify service readiness

**Tilli Infrastructure Stack:**

| Component | Technology |
|-----------|-----------|
| CI/CD | GitHub Actions |
| Container Registry | AWS ECR |
| Compute | AWS ECS |
| Secrets | AWS Secrets Manager |
| Monitoring | Datadog |
| Source Control | GitHub (CODEOWNERS + branch protection) |
| Task Tracking | Jira |
| Documentation | SharePoint |

---

### 6. Security Fundamentals

> **AIMS Reference**: Article V §3.5, Article VII (Risk Management), Article XV (Prohibited Conduct)

| Skill | Junior | Mid | Senior |
|-------|--------|-----|--------|
| Input validation | Validates at form level | Validates at API boundary | Designs validation schemas |
| OWASP awareness | Knows the Top 10 | Prevents common vulnerabilities | Conducts security reviews |
| Secret management | Doesn't commit secrets | Uses AWS Secrets Manager | Designs secret rotation |
| Dependency security | Runs `npm audit` | Triages vulnerabilities | Implements supply chain security |
| Data classification | Understands PCI/PII/PHI | Applies correct controls | Designs data governance |

**Key Lessons from Production:**

> **Centralized Credentials**: Hardcoded passwords in seed scripts and test files led to credential sprawl. All demo/test credentials now live in a single `packages/config/demo-credentials.json`.

> **Environment Locking**: A developer accidentally pointed their local frontend to the production API, causing test data to leak into production. All `NEXT_PUBLIC_API_URL` values are now locked to `localhost` in development.

**Required Knowledge:**
- SQL injection prevention (parameterized queries, ORM usage) — OWASP A03:2021
- XSS prevention (output encoding, CSP headers) — OWASP A07:2021
- CSRF protection (SameSite cookies, CSRF tokens)
- Secret storage: AWS Secrets Manager for production, `.env` for dev (never committed)
- Data classification: PCI, PII, PHI — know which applies to each Tilli product
- Prohibited conduct per AIMS-001 Article XV

---

### 7. AI Governance & Compliance

> **AIMS Reference**: Articles IV–XVII (Full Governance Framework)

| Skill | Junior | Mid | Senior |
|-------|--------|-----|--------|
| AI intake process | Understands `AI-INIT` workflow | Creates intake Jira tickets | Reviews and classifies AI risk |
| Risk classification | Knows Low/Moderate/High | Assesses features against criteria | Designs risk registers |
| Documentation standards | Follows BRD templates | Creates technical specifications | Ensures audit traceability |
| Incident management | Reports `AI-INCIDENT` promptly | Conducts root cause analysis | Designs corrective actions |
| Validation | Understands validation requirements | Runs performance benchmarks | Designs bias testing protocols |
| CLAUDE.md authoring | Reads and follows rules | Writes app-specific rules | Designs org-wide templates |

**Key Lesson from Production:**
> Without CLAUDE.md guardrails, AI tools would create raw SQL queries, skip auth guards, use JavaScript instead of TypeScript, and create separate database connections in route files. Every production pattern that matters must be explicitly documented as a rule.

**Required Knowledge — AI Governance:**
- AIMS-001 structure: Articles I–XIX and how they apply to daily work
- AIP-PR-001 lifecycle: Stages 1–9 (Intake → Incident Management)
- AI Risk Register fields and maintenance cadence
- Jira labels: `AI-INIT`, `AI-CHANGE`, `AI-INCIDENT`
- SharePoint documentation structure: `/AI Governance/{Product}/{System}/`
- Quarterly AI Governance Report contents (AIP-PR-001 Section 6)
- Annual developer attestation requirements (AIP-PR-001 Section 5)
- ISO/IEC 42001:2023 awareness (AIMS-001, Article I)
- Third-party AI vendor assessment process (AIMS-001, Article XIII)

**Required Knowledge — AI Development:**
- How `CLAUDE.md` files cascade (root → app → package)
- Writing clear, enforceable rules (with "NEVER" and "ALWAYS" patterns)
- Including code examples for correct and incorrect patterns
- How to verify AI-generated code against project standards
- AI-specific risks: hallucination, bias, prompt injection, model drift, data leakage

---

### 8. Tilli Product Knowledge

> **AIMS Reference**: Article III (Scope)

| Skill | Junior | Mid | Senior |
|-------|--------|-----|--------|
| Product awareness | Knows assigned product | Understands cross-product dependencies | Architects cross-product features |
| Jareis AI system | Uses Jareis-powered features | Integrates Jareis into workflows | Designs Jareis capabilities |
| Tenant architecture | Understands multi-tenancy | Implements tenant isolation | Designs tenant-to-feature mapping |
| Domain knowledge | Follows CRM/fintech patterns | Applies industry best practices | Designs domain-specific solutions |

**Required Knowledge:**
- Tilli product portfolio and which products use AI:

| Product | Category | AI System |
|---------|----------|-----------|
| tilliX | Platform | Varies |
| tilliPay | Payments | Varies |
| Nudge | CRM Core | Jareis |
| Nudge Beacon | Industry CRM | Jareis |
| Nudge CPaaS | Communications | Jareis |
| tilliArc | Architecture | Varies |
| XDEX | Exchange | Varies |
| Beacon | Analytics | Varies |

- Feature-to-tenant mapping documentation requirements
- Human oversight requirements for AI outputs in each product

---

## AI Governance Principles (AIMS-001, Article V)

Every team member must internalize these six principles:

| # | Principle | What It Means for Developers |
|---|-----------|------------------------------|
| 1 | **Responsible AI Use** | Design systems that minimize harm and prevent misuse |
| 2 | **Risk-Based Approach** | Govern AI proportionate to its impact — Low, Moderate, High |
| 3 | **Transparency** | AI capabilities must be identifiable; behavior must be explainable |
| 4 | **Human Oversight** | AI outputs affecting critical decisions must allow human review/override |
| 5 | **Security & Data Protection** | Comply with access control, logging, and data protection standards |
| 6 | **Continuous Improvement** | Monitor, evaluate, and improve AI systems based on performance and incidents |

---

## Onboarding Checklist

### Week 1 — Environment & Governance Orientation

- [ ] Clone the monorepo and run `pnpm install`
- [ ] Start all services using the management script (NOT `pnpm dev`)
- [ ] Verify all health check endpoints respond
- [ ] Read the root `CLAUDE.md` end-to-end
- [ ] Read app-specific `CLAUDE.md` files for your assigned area
- [ ] Run the test suite and verify it passes
- [ ] Understand the project structure: `apps/`, `packages/`, `scripts/`, `docs/`
- [ ] Read AIMS-001 (AI Governance Policy) — at minimum Articles III, V, VII, XV
- [ ] Read AIP-PR-001 (Procedure Manual) — at minimum Stages 1–4, 9
- [ ] Understand your AIMS role and accountability (Article IV, Section 4.2)

### Week 2 — Code & Standards

- [ ] Write a small feature using TypeScript strict mode
- [ ] Verify ESLint passes with zero warnings on your code
- [ ] Use Drizzle ORM for all database queries (no raw SQL)
- [ ] Import the database client from `@tilli/db` (not a new Pool)
- [ ] Add auth guards to any new protected pages
- [ ] Use centralized credentials from `packages/config/demo-credentials.json`
- [ ] Understand data classification for your assigned product (PCI/PII/PHI)

### Week 3 — CI/CD, Security & Monitoring

- [ ] Push a branch and verify GitHub Actions CI passes
- [ ] Read and understand the CI/CD pipeline configuration
- [ ] Review the OWASP Top 10 and how they apply to your product
- [ ] Practice running services in the correct dependency order
- [ ] Understand the database migration workflow (generate → review → apply)
- [ ] Familiarize yourself with Datadog dashboards for your product
- [ ] Review the Jira label system: `AI-INIT`, `AI-CHANGE`, `AI-INCIDENT`

### Week 4 — AI Tooling & Governance

- [ ] Set up Claude Code in your IDE
- [ ] Read this Skill.md and understand what the AI can/cannot do
- [ ] Practice writing prompts that reference CLAUDE.md rules
- [ ] Review AI-generated code for compliance with project standards
- [ ] Contribute an improvement to the project's CLAUDE.md
- [ ] Understand the AI intake process (AIP-PR-001 Stage 1)
- [ ] Know how to file an `AI-INCIDENT` and the 24-hour escalation rule
- [ ] Complete initial developer attestation (AIP-PR-001 Section 5)

---

## Anti-Patterns to Avoid

These are mistakes that were made in production and are now explicitly forbidden:

| Anti-Pattern | Why It's Dangerous | What To Do Instead | AIMS Reference |
|-------------|-------------------|-------------------|----------------|
| `new Pool()` in a route file | Connection pool exhaustion | Import from `@tilli/db` | AIP Stage 4 |
| Raw SQL strings | SQL injection + no type safety | Use Drizzle ORM | Art. V §3.5 |
| `DROP TABLE` / `TRUNCATE` | Data loss, no recovery | Additive migrations only | Art. XII |
| Manual `pnpm dev` | Zombie processes, port conflicts | Use service management script | AIP Stage 6 |
| Skipping auth guards | Unauthorized access to pages | `useAuth()` + redirect pattern | Art. V §3.4 |
| Hardcoded passwords | Credential sprawl | `packages/config/demo-credentials.json` | Art. XIV |
| `any` type everywhere | Defeats TypeScript's purpose | Explicit types, generics | Art. V §3.5 |
| Apps importing from apps | Circular dependencies | Shared packages only | AIP Stage 4 |
| Changing `/api/auth/me` shape | Breaks all frontends | Immutable contract | Art. V §3.4 |
| Removing tests to pass CI | Hides bugs | Fix the underlying issue | Art. V §3.6 |
| `.env.local` with prod URLs | Data leak risk | Lock to `localhost` | AIP Stage 4 |
| CommonJS `require()` | Module system inconsistency | ES Modules with `import` | AIP Stage 4 |
| Deploying AI without intake | Governance violation | File `AI-INIT` Jira first | Art. VI |
| Ignoring AI incidents | Regulatory exposure | Report within 24 hours | Art. XI |
| Unvetted third-party AI | Prohibited conduct | Vendor assessment required | Art. XIII, XV |
| Deploying biased AI | Discriminatory outcomes | Bias testing before deploy | Art. VII, XV |

---

## Model Validation Competency (Moderate & High Risk)

> **AIMS Reference**: Article IX, AIP-PR-001 Stage 5

For team members involved in Moderate or High-Risk AI systems, additional validation skills are required:

| Validation Area | What It Covers | Who Must Know |
|----------------|---------------|---------------|
| Conceptual model review | Is the AI approach sound for the business problem? | Engineering Lead, Product Owner |
| Data integrity assessment | Is training/input data clean, complete, representative? | Data Team, Engineering |
| Reproducibility testing | Can results be consistently reproduced? | Engineering |
| Performance benchmarking | Does the model meet accuracy/latency requirements? | Engineering |
| Bias and fairness testing | Are outputs fair across demographics and scenarios? | AI Governance Lead, Engineering |
| False positive/negative analysis | What are the error rates and their business impact? | Product Owner, Engineering |
| Stress testing | How does the model behave under load/adversarial input? | Security Team, Engineering |
| Monitoring threshold definition | What metrics trigger alerts? | Engineering, Operations |

**High-Risk systems require an independent validator** — someone not involved in the system's development.

---

## Annual Developer Attestation

> **AIMS Reference**: AIP-PR-001 Section 5

Every engineer working on AI-enabled features must annually attest to:

- [ ] **Compliance with AIMS**: I have read and understand AIMS-001 and AIP-PR-001
- [ ] **Data handling**: I handle regulated data (PCI/PII/PHI) securely per company standards
- [ ] **Intake adherence**: I follow the AI intake and validation requirements before deployment
- [ ] **Incident escalation**: I will report AI incidents within 24 hours via Jira `AI-INCIDENT`

Records retained for minimum **5 years**.

---

## Quarterly AI Governance Report Awareness

> **AIMS Reference**: AIP-PR-001 Section 6

All team members should understand the Quarterly AI Governance Report, prepared by the AI Review Committee (ARC):

| Report Section | What It Contains |
|---------------|-----------------|
| AI system inventory | All active AI systems and their risk levels |
| Risk distribution | Low / Moderate / High breakdown across products |
| Validation status | Which systems have completed validation |
| Incident summary | AI-related incidents and corrective actions |
| Drift/performance trends | Model performance over time |
| Regulatory updates | New regulations or compliance requirements |
| Governance KPIs | Intake compliance, incident response times, attestation rates |

Board escalation required for material AI incidents.

---

## Continuous Improvement

This document should be updated when:

1. A new production incident reveals a lesson not yet captured.
2. A new Tilli product or AI capability is introduced.
3. AIMS-001 or AIP-PR-001 is updated.
4. An anti-pattern is discovered that should be added to the forbidden list.
5. The onboarding process is refined based on new-hire feedback.
6. ISO/IEC 42001 audit findings require skill updates.

**Review cadence**: Quarterly, aligned with the AI Governance Report cycle, or after any P0/P1 incident.

---

*Document ID: AIMS-SKILL-001 | Version: 1.0 | Tilli Software*
*Aligned with AIMS-001 (AI Governance Policy) and AIP-PR-001 (Procedure Manual)*
*Drafted by: Amit Kumar, Syed Shoeb, Suryakant Thombare | Reviewed by: Raja Vemuri*
*Effective: 01-01-2026 | Next Review: Quarterly*
