# CLAUDE.md — Tilli Software AI-Assisted Development Guardrails

> **Document ID**: AIMS-CLAUDE-001
> **Alignment**: AIMS-001 (Consolidated) — AI Governance Policy & Procedure Manual
> **Organization**: Tilli Software
> **Owner**: CTO (Operational) / AI Governance Lead (Oversight)
> **Review Cycle**: Quarterly
> **Effective Date**: 01-01-2026

> **Purpose**: This is the standard `CLAUDE.md` template for all Tilli Software repositories.
> Claude Code reads this file automatically and treats its contents as **binding instructions**.
> Every rule here operationalizes the Tilli AI Governance Policy (AIMS-001, Articles V–XV)
> and the AI Governance Procedure Manual (AIP-PR-001, Stages 1–9).

---

## How to Use This Template

1. Copy this file into the **root** of your repository as `CLAUDE.md`.
2. Replace every `<PLACEHOLDER>` with project-specific values.
3. Add nested `CLAUDE.md` files inside `apps/` or `packages/` for app-specific rules — Claude merges them all.
4. Commit the file to source control so every contributor (human and AI) sees the same rules.
5. **Jira label**: All AI-related work must carry `AI-INIT`, `AI-CHANGE`, or `AI-INCIDENT` labels per AIP-PR-001.

---

## Project Overview

- **Project Name**: `<PROJECT_NAME>`
- **Tilli Product**: `<tilliX | tilliPay | Nudge | Nudge Beacon | Nudge CPaaS | tilliArc | XDEX | Beacon | Other>`
- **AI System (if applicable)**: `<Jareis | Third-Party | None>`
- **Description**: `<One-line description>`
- **Monorepo Tool**: pnpm workspaces + Turborepo (mandatory)
- **Language**: TypeScript (strict mode) — no JavaScript allowed
- **Module System**: ES Modules only (`"type": "module"` in package.json)
- **AI Risk Classification**: `<Low | Moderate | High>` (per AIMS-001, Article VII)
- **Data Classification**: `<PCI | PII | PHI | Internal | Public>` (per AIP-PR-001, Stage 2.1)

---

## AIMS Governance Alignment

> **Reference**: AIMS-001 Articles IV–VII, AIP-PR-001 Stages 1–3

### AI Risk Classification (AIMS-001, Article VII)

Every AI-enabled feature in this repository must be classified:

| Risk Level | Criteria | Approval Required |
|-----------|---------|-------------------|
| **Low** | No financial or customer impact | Engineering Lead |
| **Moderate** | Customer-facing analytics or optimization | Engineering Lead + Product Owner |
| **High** | Financial decisioning, fraud detection, regulatory impact | AI Review Committee (ARC) |

**High-Risk AI systems require independent validation before production deployment** (AIMS-001, Article IX).

### AI Lifecycle Compliance (AIMS-001, Article VI)

No AI system shall be deployed without completion of:

- [ ] Formal intake and risk classification (Jira Epic: `AI-INIT`)
- [ ] Documented business and technical specifications
- [ ] Validation (Moderate & High Risk)
- [ ] Security review
- [ ] Monitoring configuration (Datadog dashboards + alerts)
- [ ] Deployment approval (GitHub Actions CI/CD only)

### Required Documentation (AIMS-001, Article VIII)

Stored in: `/AI Governance/{Product}/{System}/` (SharePoint)

- [ ] Business Requirements Document (BRD)
- [ ] Functional Specification
- [ ] Technical Specification
- [ ] Architecture Diagram
- [ ] Risk Classification Form
- [ ] Monitoring Plan
- [ ] Deployment Approval Record

**Development may not begin without documentation folder creation.**

### Prohibited Conduct (AIMS-001, Article XV)

The following are **strictly prohibited** and may result in disciplinary action:

- Use of regulated data (PCI/PII/PHI) without documented approval
- Deployment outside the formal AI intake workflow (`AI-INIT` → ARC review)
- Integration of unvetted third-party AI services
- Circumvention of monitoring or security controls
- Deployment of AI systems demonstrating unacceptable bias or discriminatory outcomes

---

## Lesson #1 — Always Use a Monorepo

### Why

- Shared packages (`@tilli/db`, `@tilli/ui`, `@tilli/config`, `@tilli/sdk`, `@tilli/shared`) eliminate duplication.
- Atomic commits across frontend + backend keep versions in sync.
- Turborepo caching makes CI dramatically faster after the first run.
- Aligns with AIMS-001 Article VIII: traceable through version control.

### Standard Tilli Monorepo Structure

```
<project>/
├── pnpm-workspace.yaml
├── turbo.json
├── CLAUDE.md                    ← This file
├── apps/
│   ├── api/                     # Backend API (Fastify/Express)
│   ├── web/                     # Consumer-facing app
│   ├── admin-portal/            # Admin dashboard
│   └── <additional-apps>/
├── packages/
│   ├── db/                      # ORM schemas, migrations, shared DB client
│   ├── sdk/                     # Shared SDK
│   ├── shared/                  # Shared utilities
│   ├── ui/                      # Shared UI components
│   └── config/                  # Shared config, credentials, constants
├── docs/                        # Technical documentation
│   ├── SETUP.md
│   └── PORTS.md
├── scripts/                     # Service management scripts
└── .github/
    └── workflows/               # GitHub Actions CI/CD
```

### Rules

- **Module isolation is enforced by ESLint** — apps CANNOT import from other apps.
- Cross-app sharing MUST go through `packages/*`.
- Every package has its own `package.json` with a scoped name (`@tilli/<pkg>`).
- Repository must use CODEOWNERS for review policies (AIMS-001, Article IV).
- Branch protection must be enabled on `main` and `develop` branches.

---

## Lesson #2 — TypeScript + ESLint Compliance Is Non-Negotiable

> **Governance**: AIMS-001 Article V §3.5 (Security and Data Protection), AIP-PR-001 Stage 4

### TypeScript Rules

| Rule | Enforcement |
|------|-------------|
| Strict mode enabled | `tsconfig.json` → `"strict": true` |
| No `any` without justification | ESLint `@typescript-eslint/no-explicit-any` |
| All function params typed | Compiler enforced |
| Return types explicit or inferred | Code review enforced |
| No `.js` / `.jsx` source files | Build fails if found |
| CommonJS forbidden | `"type": "module"` in package.json; use `.cjs` only for config files |

### ESLint Configuration

Use `@typescript-eslint` with the recommended + strict configs:

```jsonc
// eslint.config.mjs (flat config)
{
  "extends": [
    "eslint:recommended",
    "plugin:@typescript-eslint/recommended",
    "plugin:@typescript-eslint/strict"
  ],
  "rules": {
    "@typescript-eslint/no-explicit-any": "error",
    "@typescript-eslint/no-unused-vars": ["error", { "argsIgnorePattern": "^_" }],
    "no-console": ["warn", { "allow": ["warn", "error"] }]
  }
}
```

### Why This Matters

- Type errors caught at build time save hours of runtime debugging.
- Consistent style across the team eliminates bikeshedding in code reviews.
- AI assistants generate safer code when strict rules are in the context.
- Supports AIMS-001 Article V §3.5: security through type safety.

---

## Lesson #3 — Single Database Connection (No Multiple Pool Requests)

> **Governance**: AIP-PR-001 Stage 4 (Development Controls)

### The Problem We Solved

Creating ad-hoc `new Pool()` instances inside route files led to:
- Connection pool exhaustion under load
- Inconsistent SSL / auth configuration between routes
- Hard-to-debug "too many connections" crashes in production

### The Rule

> **ONE shared database client, exported from a single package.**
> Every app imports from `@tilli/db`. No raw `new Pool()` anywhere else.

### Correct Pattern

```typescript
// packages/db/src/index.ts  — the ONLY place a connection is created
import { drizzle } from 'drizzle-orm/node-postgres';
import { Pool } from 'pg';
import * as schema from './schema';

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: 20,  // single, tuned pool
});

export const db = drizzle(pool, { schema });
export * from './schema';
```

```typescript
// In any app route — CORRECT
import { db, users } from '@tilli/db';

const result = await db.select().from(users).where(eq(users.id, id));
```

```typescript
// ❌ FORBIDDEN — never do this in a route file
import { Pool } from 'pg';
const pool = new Pool({ host: 'localhost', ... });
```

### Why This Matters

- One pool = one place to tune `max`, `idleTimeoutMillis`, connection strings.
- Prevents SSL mismatches between dev (no SSL) and prod (SSL required).
- Drizzle ORM generates TypeScript types from your schema automatically.
- Secrets stored in AWS Secrets Manager, not hardcoded (AIP-PR-001 Stage 4).

---

## Lesson #4 — Never Drop the Database

> **Governance**: AIMS-001 Article V §3.6 (Continuous Improvement), Article XII (Change Management)

### The Rule

> **NEVER run `DROP DATABASE`, `DROP TABLE`, `TRUNCATE`, or destructive DDL in any environment that has real data.**

### Safe Migration Workflow

1. Define schema changes in TypeScript (Drizzle schema files).
2. Generate migrations: `pnpm drizzle-kit generate`
3. Review the generated SQL before applying.
4. Apply with `pnpm drizzle-kit push` (dev) or `pnpm drizzle-kit migrate` (production).
5. **Additive changes only** — add columns, add tables, add indexes.
6. To remove a column: mark it deprecated → deploy code that stops reading it → remove in a later migration.

### What To Do Instead of Dropping

| Situation | Wrong | Right |
|-----------|-------|-------|
| Schema out of sync | `DROP TABLE` + recreate | Fix the migration / push the diff |
| Bad data in dev | `TRUNCATE` | Seed script that resets cleanly |
| Column rename | Drop + re-add | Add new column → backfill → remove old |
| Test isolation | Shared mutable DB | Per-test transactions that rollback |

### Financial / Immutable Ledgers

If your Tilli product uses an immutable ledger (e.g., TigerBeetle, event-sourced transactions):
- Data is **append-only** — NEVER delete, update, or truncate ledger entries.
- Corrections are made via **reversing entries**, not edits.
- The ledger is the source of truth for balances; PostgreSQL stores metadata only.
- All changes require a Jira `AI-CHANGE` ticket (AIP-PR-001 Stage 8).

---

## Lesson #5 — Use an ORM Exclusively (No Raw SQL Bypasses)

> **Governance**: AIMS-001 Article V §3.5, AIP-PR-001 Stage 4

### The Rule

> **All database operations go through the ORM (Drizzle). No raw SQL strings.**

### Why

- Raw SQL bypasses type safety — you lose compile-time checks.
- Schema drift: raw `CREATE TABLE` statements diverge from the ORM schema.
- SQL injection risk if parameterization is forgotten (OWASP A03:2021).

### Naming Convention Mapping

| Layer | Convention | Example |
|-------|-----------|---------|
| TypeScript (ORM schema) | camelCase | `partyId`, `displayName` |
| Database columns | snake_case | `party_id`, `display_name` |
| The ORM handles mapping automatically | — | — |

### Exception

Parameterized raw SQL is allowed **only** for performance-critical queries where the ORM generates inefficient SQL, and it must:
1. Use parameterized placeholders (never string interpolation).
2. Be reviewed and approved in PR by a designated reviewer.
3. Have a comment explaining why the ORM was insufficient.

---

## Lesson #6 — Service Management Scripts Are Mandatory

> **Governance**: AIP-PR-001 Stage 6 (Deployment Approval), Stage 7 (Monitoring)

### The Rule

> **Use a centralized service management script for starting, stopping, and checking services. Never run `pnpm dev` or `npm start` manually.**

### Why

- Prevents zombie Node processes that clog ports.
- Ensures services start in the correct dependency order.
- Tracks PIDs for clean shutdown.
- Prevents "EMFILE: too many open files" and port conflict errors.

### Template Script Commands

```bash
./scripts/<project>-services.sh start     # Stop existing → start in order
./scripts/<project>-services.sh stop      # Clean shutdown + port cleanup
./scripts/<project>-services.sh status    # Health check all services
./scripts/<project>-services.sh restart   # stop + start
./scripts/<project>-services.sh logs <svc> # Tail logs for a service
```

### Port Table (customize per project)

| Service | Port | Health Check |
|---------|------|--------------|
| Backend API | `<PORT>` | `http://localhost:<PORT>/api/health` |
| Web App | `<PORT>` | `http://localhost:<PORT>` |
| Admin Portal | `<PORT>` | `http://localhost:<PORT>` |
| PostgreSQL | 5432 | Docker container |
| Redis | 6379 | Docker container |

---

## Lesson #7 — Authentication Contracts Are Immutable

> **Governance**: AIMS-001 Article V §3.4 (Human Oversight), Article XII (Change Management)

### The Rule

> **The auth verification endpoint (`/api/auth/me`) is a system-critical contract. ALL frontends depend on it. Never change its shape without updating every consumer simultaneously.**

### Contract

```
GET /api/auth/me
Authorization: Bearer <token>

→ 200  { "success": true, "data": { "id", "email", "firstName", "lastName", ... } }
→ 401  { "success": false, "message": "Unauthorized" }
```

### Never Allowed

- Returning 500/503 for invalid tokens (MUST be 401).
- Adding rate limiting (429) without frontend retry logic.
- Changing the response shape without updating ALL frontend auth guards.
- Changes without a Jira `AI-CHANGE` ticket and ARC review.

### Frontend Auth Guard (Required on Every Protected Page)

```typescript
'use client';
import { useEffect } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import { useAuth } from '@/contexts/AuthContext';

export default function ProtectedPage() {
  const { isAuthenticated, isLoading } = useAuth();
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      router.push('/auth/login?redirect=' + encodeURIComponent(pathname));
    }
  }, [isLoading, isAuthenticated, router, pathname]);

  if (isLoading) return <div>Loading...</div>;
  if (!isAuthenticated) return null;

  return (/* protected content */);
}
```

---

## Lesson #8 — Environment Configuration Is Locked

> **Governance**: AIMS-001 Article V §3.5, AIP-PR-001 Stage 4 (Secrets in AWS Secrets Manager)

### The Rule

> **All frontend apps must point `NEXT_PUBLIC_API_URL` to `http://localhost:<backend_port>` in development. These values are LOCKED and must never point to external or production backends.**

### Environment Variable Management

| Environment | Method | Reference |
|-------------|--------|-----------|
| Development | `.env` based on `.env.example` | Local only, never committed |
| Staging/Production | AWS Secrets Manager or ECS Task Definitions | Managed by DevOps |

### Verification

```bash
grep -r "NEXT_PUBLIC_API_URL" apps/*/\.env.local 2>/dev/null
# Every result must show http://localhost:<PORT>
```

### Never Allowed

- Committing `.env.local` files with production URLs.
- Pointing local dev to remote backends (data leak risk).
- Inconsistent API URLs across apps.
- Hardcoding secrets in source code (AIP-PR-001 Stage 4).

---

## Lesson #9 — Centralized Credentials (Single Source of Truth)

> **Governance**: AIMS-001 Article XIV (Data Governance), AIP-PR-001 Stage 4

### The Rule

> **All demo, seed, and test credentials live in ONE file: `packages/config/demo-credentials.json`. Never hardcode passwords in seed scripts, tests, or docs.**

```typescript
import credentials from '@tilli/config/demo-credentials.json';
const adminPassword = credentials.accounts.platformAdmin.password;
```

### Never Allowed

- Hardcoded passwords in source files.
- Different passwords for the same account across environments.
- Credentials in `.env` files that could be committed.
- Secrets must be stored in AWS Secrets Manager for production.

---

## Lesson #10 — Security Invariants

> **Governance**: AIMS-001 Article V §3.5, Article VII, Article XV

### OWASP Top 10 Awareness

Claude must never introduce:
- **SQL injection** (use ORM / parameterized queries) — OWASP A03:2021
- **XSS** (sanitize all user input rendered in HTML) — OWASP A07:2021
- **Command injection** (never pass user input to `exec` / `spawn`)
- **Insecure deserialization** — OWASP A08:2021
- **Broken access control** (every route needs auth + authorization guards) — OWASP A01:2021

### AI-Specific Security Risks (AIMS-001, Article VII)

Every AI-enabled feature must assess and mitigate:

| Risk | Mitigation | Owner |
|------|-----------|-------|
| Hallucinated output | Human review for high-impact workflows | Product Owner |
| Data leakage | Access controls & sanitized prompts | Security Team |
| Model drift | Periodic output review | Engineering Lead |
| Prompt injection | Input validation & filtering | Engineering Lead |
| Bias / discriminatory outcomes | Bias testing before deployment | AI Governance Lead |

### Capability-Based Access Control (CBAC)

- Capability format: `{domain}.{action}` (e.g., `wallet.read`, `treasury.admin`).
- Every protected route MUST have a capability guard.
- New routes require defining capabilities before implementation.

### Secrets Management

- Never commit `.env` files with real secrets.
- Production secrets in AWS Secrets Manager (AIP-PR-001 Stage 4).
- Rotate secrets on schedule; never share across environments.

---

## Lesson #11 — CI/CD Pipeline Standards

> **Governance**: AIMS-001 Article XII, AIP-PR-001 Stage 6 (Deployment Only via GitHub Actions CI/CD)

### Required Pipeline Steps (GitHub Actions)

1. **Lint** — ESLint + TypeScript compiler (`tsc --noEmit`).
2. **Type Check** — Validate all TypeScript types.
3. **Test** — Unit + integration tests pass.
4. **Build** — All apps build successfully.
5. **Migration Validation** — Drizzle migrations are valid.
6. **Docker** — Images build and push to AWS ECR.
7. **Deploy** — Automated deploy to ECS; rollback capability required.

### Infrastructure

| Component | Technology |
|-----------|-----------|
| CI/CD | GitHub Actions |
| Container Registry | AWS ECR |
| Compute | AWS ECS |
| Secrets | AWS Secrets Manager |
| Monitoring | Datadog |
| Source Control | GitHub (CODEOWNERS + branch protection) |

### Authentication

- Use OIDC (OpenID Connect) for CI/CD → AWS auth (no long-lived credentials).
- Trust policies restrict to specific repos and branches.

### Post-Deploy Gates

- Health check endpoints must return 200.
- Smoke tests run automatically after deploy.
- Rollback if any gate fails.
- **High-Risk AI deployments require ARC approval** (AIMS-001, Article VI).

---

## Lesson #12 — Never Remove Functionality to Pass Tests

> **Governance**: AIMS-001 Article V §3.6 (Continuous Improvement)

### The Rule

> **If a test fails, fix the underlying issue. Never delete the test, remove the feature, or stub out functionality just to make CI green.**

### What To Do Instead

| Situation | Wrong | Right |
|-----------|-------|-------|
| Test expects a field that doesn't exist | Remove the test | Add the missing field/column |
| Feature broke after refactor | Delete the feature code | Fix the refactor to preserve behavior |
| Flaky test | Skip it permanently | Fix the root cause (timing, state leak) |

---

## AI System Monitoring & Incident Management

> **Governance**: AIMS-001 Articles X–XI, AIP-PR-001 Stages 7–9

### Monitoring Requirements (All AI-Enabled Features)

| Requirement | Tool | Cadence |
|-------------|------|---------|
| Model version + decision metadata logging | Datadog | Continuous |
| Performance dashboards | Datadog | Continuous |
| Alert thresholds defined | Datadog | Before deployment |
| Drift monitoring (if applicable) | Datadog | Per risk level |
| Input/output logging (privacy-compliant) | Application logs | Continuous |

### Monitoring Review Cadence

| Risk Level | Review Frequency |
|-----------|-----------------|
| High | Quarterly |
| Moderate | Biannual |
| Low | Annual |

### AI Incident Response (AIP-PR-001 Stage 9)

When an AI-related incident occurs:

1. Create Jira ticket labeled `AI-INCIDENT`
2. Notify Security & Compliance within **24 hours**
3. Assess financial and regulatory impact
4. Disable feature if necessary
5. Conduct root cause analysis
6. Document corrective actions
7. Update AI Risk Register if new risks identified

---

## Change Management for AI Systems

> **Governance**: AIMS-001 Article XII, AIP-PR-001 Stage 8

### Material Changes Requiring Governance Review

All material changes require a Jira ticket labeled `AI-CHANGE`:

- New training dataset
- Model architecture change
- Jurisdiction expansion
- New financial impact logic
- Prompt template modifications
- Third-party AI provider changes

### Requirements for Material Changes

- [ ] Updated risk assessment
- [ ] Updated documentation in SharePoint
- [ ] Re-validation (if required)
- [ ] ARC approval (if risk elevated to High)
- [ ] Rollback plan documented

---

## Third-Party AI Governance

> **Governance**: AIMS-001 Article XIII

When using external AI providers (OpenAI, Anthropic, Google, etc.):

- [ ] Vendor risks evaluated and documented
- [ ] Data sharing implications assessed (PCI/PII/PHI classification)
- [ ] Contractual and compliance obligations reviewed
- [ ] Security controls validated
- [ ] Vendor assessment completed (per Procurement and Security procedures)

**Integration of unvetted third-party AI services is PROHIBITED** (AIMS-001, Article XV).

---

## Tilli Product-Specific Notes

### Products In Scope (AIMS-001, Article III)

| Product | AI System | Primary Risk Area |
|---------|-----------|-------------------|
| tilliX | Varies | Financial decisioning |
| tilliPay | Varies | Payment processing |
| Nudge | Jareis | CRM automation |
| Nudge Beacon | Jareis | Agent assistance, workflow intelligence |
| Nudge CPaaS | Jareis | Communication platform AI |
| tilliArc | Varies | Architecture platform |
| XDEX | Varies | Exchange operations |
| Beacon | Varies | Analytics |

### Nudge Beacon Reference Architecture

```
User → Web UI (React/TS) → Backend API (Fastify/TS) → Jareis AI → Response
                                    ↓
                              PostgreSQL 16 (Drizzle ORM)
                                    ↓
                              Datadog Monitoring
```

---

## Service-Specific CLAUDE.md Files

Place additional `CLAUDE.md` files in each app or package directory:

```
apps/
├── api/CLAUDE.md                # Middleware, routes, DB conventions
├── web/CLAUDE.md                # Consumer UI standards
├── admin-portal/CLAUDE.md       # Admin UI patterns
packages/
├── db/CLAUDE.md                 # Schema conventions, migration rules
├── sdk/CLAUDE.md                # SDK usage rules
└── shared/CLAUDE.md             # Shared utility patterns
```

Claude merges all `CLAUDE.md` files in the directory tree, so rules cascade naturally.

---

## Developer Annual Attestation

> **Governance**: AIP-PR-001 Section 5

All AI contributors must annually attest to:

- [ ] Compliance with AIMS-001 and AIP-PR-001
- [ ] Secure handling of regulated data (PCI/PII/PHI)
- [ ] Adherence to AI intake and validation requirements
- [ ] Prompt incident escalation (within 24 hours)

Records retained for minimum **5 years**.

---

## Quick Reference Card

| Category | Rule | Severity | AIMS Reference |
|----------|------|----------|----------------|
| Language | TypeScript strict, no JS | BLOCKING | Art. V §3.5 |
| Modules | ES Modules only, no CommonJS | BLOCKING | AIP Stage 4 |
| ORM | Drizzle only, no raw SQL | BLOCKING | Art. V §3.5 |
| DB Connection | Single shared pool from `@tilli/db` | BLOCKING | AIP Stage 4 |
| DB Safety | Never DROP/TRUNCATE production data | CRITICAL | Art. XII |
| Auth | `/api/auth/me` contract is immutable | CRITICAL | Art. V §3.4 |
| Auth Guards | Every protected page has useAuth guard | CRITICAL | Art. V §3.4 |
| Monorepo | Apps cannot import from other apps | BLOCKING | AIP Stage 4 |
| Services | Use management script, not manual commands | MANDATORY | AIP Stage 6 |
| Env Config | API URL locked to localhost in dev | MANDATORY | AIP Stage 4 |
| Credentials | Single source in `packages/config/` | MANDATORY | Art. XIV |
| Tests | Never remove tests to pass CI | MANDATORY | Art. V §3.6 |
| Security | OWASP Top 10 awareness on every change | MANDATORY | Art. V §3.5 |
| AI Intake | Jira `AI-INIT` before development | MANDATORY | AIP Stage 1 |
| AI Risk | Risk classification before deployment | MANDATORY | Art. VII |
| AI Monitoring | Datadog dashboards before go-live | MANDATORY | Art. X |
| AI Incidents | Escalate within 24 hours | MANDATORY | Art. XI |
| Third-Party AI | Vendor assessment before integration | MANDATORY | Art. XIII |
| Prohibited | No unvetted AI, no bias deployment | BLOCKING | Art. XV |

---

*Document ID: AIMS-CLAUDE-001 | Version: 1.0 | Tilli Software*
*Aligned with AIMS-001 (AI Governance Policy) and AIP-PR-001 (Procedure Manual)*
*Drafted by: Engineering Team | Reviewed by: Raja Vemuri*
*Effective: 01-01-2026 | Next Review: Quarterly*
