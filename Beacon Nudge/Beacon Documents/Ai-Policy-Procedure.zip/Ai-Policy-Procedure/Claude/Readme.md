# Tilli Software — AI-Assisted Development Guardrails

> **Document ID**: AIMS-README-001
> **Organization**: Tilli Software
> **Alignment**: AIMS-001 (Consolidated) — AI Governance Policy & AIMS Manual
> **Adopted By**: Board of Directors
> **Owner**: CTO (Operational) / AI Governance Lead (Oversight)
> **Effective Date**: 01-01-2026
> **Review Cycle**: Quarterly
> **Reviewer**: Raja Vemuri
> **Applies To**: Engineering, Product, Security, Compliance, Data, Operations
> **Systems Referenced**: GitHub, Jira, SharePoint, GitHub Actions, Datadog, AWS
> **Drafted By**: Amit Kumar, Syed Shoeb, Suryakant Thombare

---

## What This Is

This folder contains the **operational guardrails** that bridge Tilli Software's AI Governance Policy (AIMS-001) with the day-to-day reality of writing code. These documents translate the 19 Articles of the Governance Policy and 9 Stages of the Procedure Manual into actionable rules that both human developers and AI coding assistants (Claude Code) follow automatically.

These are not theoretical guidelines — they are battle-tested guardrails born from production incidents across Tilli's product portfolio, combined with formal governance requirements aligned to **ISO/IEC 42001:2023**.

---

## Files in This Folder

| File | Document ID | Purpose | Where It Goes |
|------|-------------|---------|---------------|
| **Claude.md** | AIMS-CLAUDE-001 | Project-level AI guardrails for every repository | Root of every Tilli repository as `CLAUDE.md` |
| **Skill.md** | AIMS-SKILL-001 | Team competency framework, onboarding, attestation | Shared with all Engineering, Product, Security teams |
| **Readme.md** | AIMS-README-001 | This file — explains the system and governance mapping | Stays in this folder |

---

## Governance Framework Mapping

### How These Files Operationalize AIMS-001

| AIMS-001 Article | What It Requires | Operationalized In |
|-----------------|------------------|-------------------|
| **Art. III** — Scope | All Tilli AI products governed | Claude.md (Product table), Skill.md (Product knowledge) |
| **Art. IV** — Governance Structure | ARC, roles, accountability | Skill.md (AIMS Role Mapping) |
| **Art. V** — Principles | Responsible AI, transparency, security | Claude.md (Lessons 2, 7, 10), Skill.md (Principles table) |
| **Art. VI** — Lifecycle | Intake → deploy lifecycle gates | Claude.md (AI Lifecycle Compliance checklist) |
| **Art. VII** — Risk Management | Risk registers, classification | Claude.md (Risk Classification table, AI-specific risks) |
| **Art. VIII** — Documentation | BRD, specs, architecture diagrams | Claude.md (Required Documentation checklist) |
| **Art. IX** — Validation | Independent validation for High-Risk | Skill.md (Model Validation Competency matrix) |
| **Art. X** — Monitoring | Logging, alerting, dashboards | Claude.md (Monitoring Requirements, Datadog) |
| **Art. XI** — Incidents | 24-hour escalation, root cause | Claude.md (AI Incident Response), Skill.md (Incident skill) |
| **Art. XII** — Change Management | `AI-CHANGE` workflow | Claude.md (Change Management section) |
| **Art. XIII** — Third-Party AI | Vendor assessment | Claude.md (Third-Party AI Governance checklist) |
| **Art. XIV** — Data Governance | PCI/PII/PHI handling | Claude.md (Lesson 9, Security Invariants) |
| **Art. XV** — Prohibited Conduct | No unvetted AI, no bias | Claude.md (Prohibited Conduct), Skill.md (Anti-patterns) |
| **Art. XVI** — Reporting | Quarterly governance report | Skill.md (Quarterly Report Awareness) |
| **Art. XVII** — Audit & Improvement | Annual review, continuous improvement | All three files (Continuous Improvement sections) |

### How These Files Operationalize AIP-PR-001

| AIP-PR-001 Stage | What It Requires | Operationalized In |
|-----------------|------------------|-------------------|
| **Stage 1** — AI Intake | Jira `AI-INIT`, risk inputs | Claude.md (AI Lifecycle Compliance) |
| **Stage 2** — Risk Classification | Low / Moderate / High | Claude.md (Risk Classification table) |
| **Stage 3** — Documentation | SharePoint folder, BRD, specs | Claude.md (Required Documentation) |
| **Stage 4** — Development Controls | GitHub, protected branches, secrets | Claude.md (Lessons 1–5, 8–9) |
| **Stage 5** — Validation | Bias testing, benchmarking | Skill.md (Validation Competency matrix) |
| **Stage 6** — Deployment | GitHub Actions only, rollback | Claude.md (Lesson 11, CI/CD) |
| **Stage 7** — Monitoring | Datadog, drift, alerting | Claude.md (Monitoring section) |
| **Stage 8** — Change Management | `AI-CHANGE`, re-validation | Claude.md (Change Management section) |
| **Stage 9** — Incidents | `AI-INCIDENT`, 24hr escalation | Claude.md (Incident Response) |

---

## How to Use These Documents

### Step 1: Copy `Claude.md` into Every Tilli Repository

```bash
cp Claude.md /path/to/your/tilli-project/CLAUDE.md
```

Open the file and replace all `<PLACEHOLDER>` values:
- **Project Name**: e.g., `TilliBeacon`, `tilliPay`, `NudgeCPaaS`
- **Tilli Product**: Select from the product list in Article III
- **AI System**: `Jareis`, `Third-Party`, or `None`
- **AI Risk Classification**: `Low`, `Moderate`, or `High`
- **Data Classification**: `PCI`, `PII`, `PHI`, `Internal`, or `Public`
- **Port numbers**: Customize for your service architecture

### Step 2: Create App-Specific CLAUDE.md Files

For monorepos, add focused `CLAUDE.md` files in each app:

```
TilliBeacon/                         (example)
├── CLAUDE.md                        ← Root template (from Claude.md)
├── apps/
│   ├── api/CLAUDE.md                ← Fastify backend rules
│   ├── web/CLAUDE.md                ← React frontend rules
│   └── admin-portal/CLAUDE.md       ← Admin UI rules
└── packages/
    └── db/CLAUDE.md                 ← Drizzle ORM / migration rules
```

Claude Code automatically reads and merges all `CLAUDE.md` files in the directory tree.

### Step 3: Share `Skill.md` with the Team

Use `Skill.md` as:
- An **onboarding checklist** for new engineers (4-week program)
- A **competency assessment** for existing team members
- A **reference for code review** standards
- A **training roadmap** for AI governance skills
- A **compliance tool** for the annual developer attestation (AIP-PR-001 Section 5)

### Step 4: Iterate Based on Incidents and Audits

After every production incident, AI-related incident, or governance audit:
1. Create Jira ticket (`AI-INCIDENT` or improvement ticket)
2. Identify the root cause
3. Determine if a guardrail could have prevented it
4. Add the lesson to `Claude.md` (as a rule) and `Skill.md` (as a skill requirement)
5. Commit the update so Claude learns immediately
6. Report in the next Quarterly AI Governance Report

---

## The 12 Engineering Lessons + Governance Overlay

These core lessons from production experience, now mapped to AIMS governance:

| # | Lesson | Impact | AIMS Reference |
|---|--------|--------|----------------|
| 1 | **Always use a monorepo** | Prevents version drift, enables atomic commits | Art. VIII |
| 2 | **TypeScript + ESLint is non-negotiable** | Catches bugs at build time, not runtime | Art. V §3.5 |
| 3 | **Single database connection** | Prevents connection pool exhaustion | AIP Stage 4 |
| 4 | **Never drop the database** | Prevents catastrophic data loss | Art. XII |
| 5 | **ORM exclusively, no raw SQL** | Type safety, prevents SQL injection | Art. V §3.5 |
| 6 | **Service management scripts** | Prevents zombie processes, port conflicts | AIP Stage 6 |
| 7 | **Auth contracts are immutable** | Prevents breaking all frontends | Art. V §3.4 |
| 8 | **Environment config is locked** | Prevents dev-to-prod data leaks | AIP Stage 4 |
| 9 | **Centralized credentials** | Prevents credential sprawl | Art. XIV |
| 10 | **Security invariants (OWASP + AI risks)** | Prevents vulnerabilities + AI-specific risks | Art. V §3.5, VII |
| 11 | **CI/CD pipeline standards** | GitHub Actions, OIDC, automated gates | Art. XII, AIP Stage 6 |
| 12 | **Never remove functionality to pass tests** | Fix the issue, don't hide it | Art. V §3.6 |

---

## Why CLAUDE.md Matters for Tilli

Claude Code reads `CLAUDE.md` files automatically at the start of every session. Without them, AI tools violate every lesson we've learned:

### Without CLAUDE.md (Governance Violations)

| AI Behavior | AIMS Violation |
|-------------|----------------|
| Creates raw SQL queries | Art. V §3.5, OWASP A03 |
| Creates new database connection pools | AIP Stage 4 |
| Skips authentication guards | Art. V §3.4 |
| Uses JavaScript instead of TypeScript | Art. V §3.5 |
| Hardcodes credentials | Art. XIV, AIP Stage 4 |
| Removes tests to make CI pass | Art. V §3.6 |
| Deploys without intake process | Art. VI, Art. XV |
| Ignores data classification | Art. XIV |

### With CLAUDE.md (Governance Compliance)

| AI Behavior | AIMS Compliance |
|-------------|-----------------|
| Uses Drizzle ORM exclusively | Art. V §3.5 |
| Imports from `@tilli/db` shared package | AIP Stage 4 |
| Adds auth guards to every protected page | Art. V §3.4 |
| Writes strict TypeScript with proper types | Art. V §3.5 |
| References centralized credentials | Art. XIV |
| Fixes test failures at root cause | Art. V §3.6 |
| Flags AI features needing `AI-INIT` intake | Art. VI |
| Respects data classification boundaries | Art. XIV |

**The CLAUDE.md file is the operational bridge between Tilli's AI Governance Policy and the code that ships.**

---

## Tilli Products In Scope (AIMS-001, Article III)

| Product | Category | AI System | Primary Risk Area |
|---------|----------|-----------|-------------------|
| tilliX | Platform | Varies | Financial decisioning |
| tilliPay | Payments | Varies | Payment processing |
| Nudge | CRM Core | Jareis | CRM automation |
| Nudge Beacon | Industry CRM | Jareis | Agent assistance, workflow intelligence |
| Nudge CPaaS | Communications | Jareis | Communication platform AI |
| tilliArc | Architecture | Varies | Architecture platform |
| XDEX | Exchange | Varies | Exchange operations |
| Beacon | Analytics | Varies | Analytics |

Additional products as designated by leadership.

---

## Tilli Technology Stack

| Component | Technology | AIMS Relevance |
|-----------|-----------|----------------|
| Language | TypeScript (strict mode) | Art. V §3.5 — Security |
| Framework (Backend) | Fastify / Express (Node.js) | AIP Stage 4 — Dev Controls |
| Framework (Frontend) | React | AIP Stage 4 — Dev Controls |
| ORM | Drizzle ORM | Art. V §3.5 — No raw SQL |
| Database | PostgreSQL 16 | AIP Stage 4 — Shared connection |
| AI System | Jareis (internal) | Art. III — In-scope AI |
| Monorepo | pnpm + Turborepo | Art. VIII — Traceability |
| CI/CD | GitHub Actions | AIP Stage 6 — Deployment only via CI/CD |
| Container Registry | AWS ECR | AIP Stage 6 |
| Compute | AWS ECS | AIP Stage 6 |
| Secrets | AWS Secrets Manager | AIP Stage 4 — Never hardcode |
| Monitoring | Datadog | AIP Stage 7 — Observability |
| Source Control | GitHub (CODEOWNERS, branch protection) | AIP Stage 4 — Protected branches |
| Task Tracking | Jira (`AI-INIT`, `AI-CHANGE`, `AI-INCIDENT`) | AIP Stages 1, 8, 9 |
| Documentation | SharePoint | AIP Stage 3 |

---

## Governance Roles & Accountability (AIMS-001, Article IV)

| Role | Responsibility | Required Attestation |
|------|---------------|---------------------|
| **AI Governance Lead** | Oversight of AI risk, compliance alignment, policy enforcement | Quarterly review |
| **Engineering Lead** | Technical implementation, controls, system integrity | Annual attestation |
| **Product Owner** | Business justification, feature approval, lifecycle oversight | Annual attestation |
| **Security Team** | Security review, data protection validation | Per-deployment |
| **Compliance / Legal** | Regulatory assessment, risk advisory | As needed |
| **AI Review Committee (ARC)** | Risk classification, High-Risk approval, quarterly reporting | Quarterly |

Named individuals and reporting structures: Per executive assignment.

---

## Jira Workflow Labels

| Label | Trigger | What Happens |
|-------|---------|-------------|
| `AI-INIT` | New AI-enabled feature | ARC reviews intake and assigns risk classification |
| `AI-CHANGE` | Material change to existing AI system | Updated risk assessment, re-validation if needed |
| `AI-INCIDENT` | AI-related incident | 24-hour notification, root cause analysis, Risk Register update |

---

## Documentation Requirements (AIMS-001, Article VIII)

All AI-enabled products must maintain in SharePoint (`/AI Governance/{Product}/{System}/`):

| Document | Required For |
|----------|-------------|
| Business Requirements Document (BRD) | All AI systems |
| Functional Specification | All AI systems |
| Technical Specification | All AI systems |
| Architecture Diagram | All AI systems |
| Risk Classification Form | All AI systems |
| Monitoring Plan | All AI systems |
| Deployment Approval Record | All AI systems |
| Validation Report | Moderate & High Risk |
| Feature-to-Tenant Mapping | Multi-tenant products |
| Data Flow Documentation | Systems handling PCI/PII/PHI |

---

## Team Adoption Playbook

### Phase 1 — Foundation (Week 1-2)

1. Copy `Claude.md` into every active Tilli repository as `CLAUDE.md`
2. Customize all `<PLACEHOLDER>` values for each product
3. Ensure every developer has Claude Code installed and configured
4. Verify Claude respects the guardrails by testing with common tasks
5. Distribute `Skill.md` to all engineering team members
6. Confirm AIMS-001 and AIP-PR-001 are accessible on SharePoint

### Phase 2 — Refinement (Week 3-4)

1. Create app-specific `CLAUDE.md` files in each monorepo
2. Run a team session to identify product-specific anti-patterns
3. Add those anti-patterns to the `CLAUDE.md` files
4. Conduct first-round developer attestations (AIP-PR-001 Section 5)
5. Verify Jira workflow labels (`AI-INIT`, `AI-CHANGE`, `AI-INCIDENT`) are active

### Phase 3 — Continuous Improvement (Ongoing)

1. After each sprint, review if any new guardrails are needed
2. After incidents, add lessons learned within 24 hours
3. Quarterly: align updates with the AI Governance Report cycle
4. Encourage developers to propose CLAUDE.md improvements via PRs
5. Annual: full AIMS review per Article XVII

---

## Compliance Checkpoints

### Before Any AI Feature Ships

- [ ] Jira `AI-INIT` ticket created and ARC has classified risk
- [ ] SharePoint documentation folder created with required artifacts
- [ ] TypeScript strict mode, ESLint passes with zero warnings
- [ ] All database access through `@tilli/db` (no raw SQL, no separate pools)
- [ ] Auth guards on all protected pages
- [ ] Security review completed (OWASP checklist)
- [ ] Datadog monitoring dashboards and alerts configured
- [ ] Rollback plan documented
- [ ] ARC approval obtained (High-Risk only)
- [ ] Deployment via GitHub Actions CI/CD only

### Quarterly

- [ ] AI Risk Registers reviewed and updated for all products
- [ ] Quarterly AI Governance Report prepared and submitted to Board
- [ ] Monitoring review completed per risk-level cadence
- [ ] CLAUDE.md files reviewed for accuracy and completeness
- [ ] Skill.md updated with new lessons learned

### Annually

- [ ] Developer attestations completed (AIP-PR-001 Section 5)
- [ ] Full AIMS review (Article XVII)
- [ ] Audit findings addressed and remediation tracked
- [ ] Third-party AI vendor assessments renewed

---

## FAQ

**Q: Which Tilli products require CLAUDE.md files?**
A: Every repository that contains code for any product listed in AIMS-001 Article III (tilliX, tilliPay, Nudge, Nudge Beacon, Nudge CPaaS, tilliArc, XDEX, Beacon, and any future products). Even non-AI products benefit from the engineering guardrails (TypeScript, ORM, monorepo rules).

**Q: What if my product doesn't use AI?**
A: Still use the Claude.md template — the 12 engineering lessons apply universally. Simply mark "AI System: None" in the Project Overview and skip the AI-specific governance sections.

**Q: Who approves High-Risk AI deployments?**
A: The AI Review Committee (ARC), per AIMS-001 Article IV and Article VI. Named individuals pending assignment by Executive Leadership.

**Q: What's the difference between `AI-INIT`, `AI-CHANGE`, and `AI-INCIDENT`?**
A: `AI-INIT` is for new AI features (triggers risk classification). `AI-CHANGE` is for material changes to existing AI systems (triggers re-assessment). `AI-INCIDENT` is for AI-related incidents (triggers 24-hour escalation and root cause analysis).

**Q: How strict should the CLAUDE.md rules be?**
A: Start strict and loosen only when a rule creates friction without adding value. Every rule in these documents exists because its absence caused a production issue or because AIMS-001 requires it for governance compliance.

**Q: What if Claude ignores a CLAUDE.md rule?**
A: Make rules specific (include code examples of right and wrong), prominent (use bold, "NEVER", "ALWAYS"), and testable (include verification commands). If Claude still ignores a rule, break it into smaller, more explicit statements.

**Q: How do nested CLAUDE.md files work?**
A: Claude Code reads all `CLAUDE.md` files from the repository root down to the current working directory. Rules in deeper files supplement or override root rules. Use this for app-specific constraints.

**Q: How does this relate to ISO/IEC 42001:2023?**
A: AIMS-001 is designed to align with ISO 42001. These operational documents are the "implemented controls" that demonstrate compliance during audits. The AIMS Article references in each section map directly to ISO 42001 requirements.

**Q: What about the Nudge Beacon technical documentation (Part C)?**
A: Part C of AIMS-001 provides the reference architecture for Nudge Beacon specifically. Use it as a model for creating similar technical documentation for other Tilli products. The structure (architecture, tech stack, AI integration, risk register, deployment) should be replicated per product.

---

## Version History

| Version | Date | Changes | Author |
|---------|------|---------|--------|
| 1.0 | 2026-02-16 | Initial release — engineering guardrails + AIMS governance mapping | Engineering Team |

---

## Related Documents

| Document | Location | Purpose |
|----------|----------|---------|
| AIMS-001 (Consolidated) | SharePoint / Board Records | Full AI Governance Policy + AIMS Manual |
| AIP-PR-001 | SharePoint | AI Governance Procedure Manual |
| ISO/IEC 42001:2023 | Standards Library | AI Management System standard |
| ISO 27001 ISMS | SharePoint | Information Security Management System |
| Product CLAUDE.md files | Each repository root | Product-specific guardrails |
| AI Risk Registers | SharePoint per product | Risk tracking and mitigation |
| Quarterly AI Governance Reports | SharePoint / Board | Governance KPIs and status |

---

*Document ID: AIMS-README-001 | Version: 1.0 | Tilli Software*
*Aligned with AIMS-001 (AI Governance Policy) and AIP-PR-001 (Procedure Manual)*
*Drafted by: Amit Kumar, Syed Shoeb, Suryakant Thombare | Reviewed by: Raja Vemuri*
*Effective: 01-01-2026 | Next Review: Quarterly*
