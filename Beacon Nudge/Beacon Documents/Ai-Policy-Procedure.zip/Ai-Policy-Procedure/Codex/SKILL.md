---
name: {{skill-name-hyphenated}}
description: {{AIMS-aligned skill purpose, trigger phrases, and risk context}}
---

# SKILL.md Template (AIMS-Aligned)

Use this file to define a reusable Codex skill that complies with Tilli AI governance controls.

## Skill Name (Human-Readable)

`{{SKILL_NAME}}`

## Governance Context

- Policy: `AIMS-001` and `AIP-PR-001`
- Owner: `CTO` / `AI Governance Lead`
- Systems: `GitHub, Jira, SharePoint, GitHub Actions, Datadog, AWS`

## Purpose

Describe exactly what this skill does and where it sits in the AI lifecycle.

## Trigger Conditions

Use this skill when:
- `{{TRIGGER_1}}`
- `{{TRIGGER_2}}`

Do not use this skill when:
- `{{ANTI_TRIGGER_1}}`

## Required Inputs

- `{{PRODUCT_NAME}}`
- `{{AI_SYSTEM_NAME}}`
- `{{RISK_LEVEL: Low|Moderate|High}}`
- `{{JIRA_TICKET}}` (`AI-INIT`, `AI-CHANGE`, or `AI-INCIDENT`)
- `{{SHAREPOINT_PATH}}` (`/AI Governance/{{Product}}/{{System}}/`)

## Workflow

1. Verify `Jira` trigger label and risk level.
2. Verify required SharePoint governance artifacts exist.
3. Execute scoped technical work with secure coding controls.
4. Run required quality gates and validation checks.
5. Produce traceable outputs for release and audit evidence.

## Mandatory AIMS Controls

1. Intake and risk control:
- No execution without valid intake/change/incident ticket.
- `High` risk always requires ARC approval before release.

2. Documentation control:
- Keep BRD, functional spec, technical spec, architecture, monitoring plan, and approval record current.

3. Security/data control:
- No hardcoded credentials.
- Secrets from AWS Secrets Manager only.
- Respect data classification rules (PCI/PII/PHI/etc.).

4. Validation control:
- `Moderate`/`High`: include validation output.
- `High`: independent validator evidence required.

5. Deployment control:
- Production changes via GitHub Actions only.
- Rollback plan required.

## Engineering Guardrails

1. TypeScript + ESLint compliant.
2. Monorepo boundaries enforced (no app-to-app imports).
3. Database safety:
- No destructive operations (`DROP`, `TRUNCATE`, schema drops).
- Additive migrations preferred, backup first.
4. Single DB access layer:
- Use shared client/package only.
- No ad-hoc pools or per-request connection creation.

## Recommended Structure

```text
{{skill-name-hyphenated}}/
├── SKILL.md
├── scripts/        # Optional deterministic helpers
├── references/     # Optional docs loaded only when needed
└── assets/         # Optional templates/resources used in outputs
```

## Verification Checklist

- [ ] Jira ticket label is valid (`AI-INIT`/`AI-CHANGE`/`AI-INCIDENT`).
- [ ] Risk level documented and current.
- [ ] Required SharePoint documentation exists and is updated.
- [ ] Validation evidence attached (`Moderate`/`High`).
- [ ] ARC approval attached (`High`).
- [ ] Datadog monitoring/logging updates included.
- [ ] Lint/typecheck/tests pass.
- [ ] No prohibited DB or security violations introduced.

## Output Contract

- Deliverables:
  - `{{DELIVERABLE_1}}`
  - `{{DELIVERABLE_2}}`
- Include:
  - Summary of changes
  - AIMS control checklist status
  - Validation performed
  - Residual risks and next review date
