# AGENTS.md Template (AIMS-Aligned)

Use this file at the repository root for Codex operating rules under Tilli AIMS.

## Document Control

- Policy name: `Artificial Intelligence Governance Policy + AIMS Manual`
- Organization: `Tilli Software`
- Document ID: `AIMS-001 (Consolidated)` + `AIP-PR-001`
- Version: `1.0`
- Adopted by: `Board of Directors`
- Owner: `CTO (Operational)` / `AI Governance Lead (Oversight)`
- Effective date: `2026-01-01`
- Review cycle: `Quarterly`
- Reviewer: `Raja Vemuri`
- Applies to: `Engineering, Product, Security, Compliance, Data, Operations`
- Systems referenced: `GitHub, Jira, SharePoint, GitHub Actions, Datadog, AWS`

## Scope

This repository must apply AIMS controls to all AI-enabled capabilities in `dev`, `staging`, and `production`, including internal AI systems and third-party AI integrations.

## Governance and Accountability

- `AI Governance Lead`: policy enforcement, risk governance, compliance alignment.
- `Engineering Lead`: secure implementation and technical controls.
- `Product Owner`: business justification and lifecycle ownership.
- `Security Team`: security controls, data protection, incident support.
- `Compliance/Legal`: regulatory interpretation and advisory.
- `ARC (AI Review Committee)`: high-risk approval, incident review, quarterly reporting.

No AI-enabled production release without named risk owner and accountable approver.

## Required AI Lifecycle Gates

1. Stage 1: Intake (`Jira` epic labeled `AI-INIT`).
2. Stage 2: Risk classification (`Low`, `Moderate`, `High`).
3. Stage 3: Mandatory documentation folder in SharePoint:
- `/AI Governance/{{Product}}/{{System}}/`
- Required files: `BRD`, functional spec, technical spec, architecture diagram, risk classification form, monitoring plan, deployment approval record.
4. Stage 4: Development controls:
- Protected branches + PR approvals.
- AI code in GitHub only.
- Model/version identifier required.
- Secrets in AWS Secrets Manager only.
- AI decision metadata logging to Datadog.
5. Stage 5: Validation:
- `Moderate` and `High` require validation report.
- `High` requires independent validation + ARC approval.
6. Stage 6: Deployment approval:
- Documentation complete, validation complete (if required), security review complete, rollback plan documented.
- Production deployment only through GitHub Actions.
7. Stage 7: Monitoring and observability:
- Input/output metadata logging (privacy-compliant), error tracking, performance monitoring, alerting thresholds, drift checks where applicable.
8. Stage 8: Change management (`Jira` label `AI-CHANGE`):
- Reassess risk, update docs, re-validate if required, ARC approval if risk elevated.
9. Stage 9: Incident management (`Jira` label `AI-INCIDENT`):
- Notify Security and Compliance within 24 hours.
- RCA + corrective/preventive actions required.
- Update AI Risk Register.

## Prohibited Conduct

- Using regulated data without documented approval.
- AI deployment outside intake/risk workflow.
- Integrating unvetted third-party AI providers.
- Circumventing monitoring or security controls.
- Releasing AI with unresolved unacceptable bias/discriminatory outcomes.

## Engineering Guardrails (Monay Lessons Learned)

1. TypeScript-first:
- New source code must be TypeScript (`.ts`/`.tsx`).
- No `@ts-nocheck` and no `@ts-ignore` without ticketed justification.

2. ESLint compliant:
- All commits must pass lint.
- No file-level `eslint-disable`.

3. True monorepo boundaries:
- No `app -> app` imports.
- Shared logic must move to `packages/*`.

4. Database safety:
- Never run destructive SQL in normal workflow:
  - `DROP TABLE`, `DROP DATABASE`, `DROP SCHEMA`, `TRUNCATE`, `ALTER ... DROP`
- Backup first for schema/data operations.
- Prefer additive migrations (`IF NOT EXISTS`, forward-safe changes).

5. Single AI/DB connection architecture:
- Use one shared DB access layer/package (example: `@monay-internal/db`).
- Do not create ad-hoc pools/clients in feature code (`new Pool()`, `postgres()`).
- Do not open per-request pools.

6. Query standards:
- Prefer Drizzle ORM and typed schema imports.
- Raw SQL only for justified edge cases with review.

7. Service orchestration:
- Use standard service scripts (example: `./scripts/monay-services.sh`) over manual process spawns.

8. Security and logging:
- Use centralized logger, not ad-hoc `console.log` in production paths.
- Never commit secrets, `.env`, logs, or generated artifacts.

## Required Local Quality Gates

```bash
pnpm lint
pnpm typecheck
pnpm test
```

## AIMS PR Checklist

- [ ] `AI-INIT` exists and risk level assigned.
- [ ] SharePoint governance folder exists with required artifacts.
- [ ] AI Risk Register updated (owner, impact, mitigations, review date).
- [ ] Validation report completed (`Moderate`/`High`).
- [ ] ARC approval attached (`High` only).
- [ ] Datadog logging/alerts updated for AI behavior.
- [ ] Rollback plan documented.
- [ ] Lint/typecheck/tests pass.
- [ ] No destructive SQL or unauthorized DB access patterns introduced.

## Repo Commands (Fill Per Repo)

```bash
{{START_COMMAND}}
{{STOP_COMMAND}}
{{STATUS_COMMAND}}
```
