# Codex Templates for Tilli AIMS

This folder provides Codex templates customized to:
- `AIMS-001 (Consolidated)` Artificial Intelligence Governance Policy
- `AIP-PR-001` Artificial Intelligence Governance Procedure Manual

## Document Profile

- Organization: `Tilli Software`
- Version: `1.0`
- Effective date: `2026-01-01`
- Review cycle: `Quarterly`
- Owner: `CTO` / `AI Governance Lead`
- Reviewer: `Raja Vemuri`
- Systems: `GitHub, Jira, SharePoint, GitHub Actions, Datadog, AWS`

## Files

- `AGENTS.md`: Repo-level operational and governance guardrails.
- `SKILL.md`: Skill template with intake/risk/validation/deployment controls.
- `README.md`: Folder index and usage.

## What Is Embedded

1. AIMS lifecycle gates:
- Intake (`AI-INIT`)
- Risk classification (`Low`, `Moderate`, `High`)
- Mandatory SharePoint documentation
- Validation and independent validation requirements
- Deployment approvals and rollback requirements
- Monitoring, change (`AI-CHANGE`), incident (`AI-INCIDENT`) workflows

2. Governance responsibilities:
- ARC oversight
- Named ownership and accountability requirement before production release

3. Engineering lessons learned:
- TypeScript + ESLint compliance
- Monorepo boundaries
- Single DB connection layer (no multiple pools)
- Strict non-destructive database policy

## How To Apply In a Repo

1. Copy `AGENTS.md` to repo root.
2. Fill placeholders (`{{PROJECT_NAME}}`, commands, owners, paths).
3. Create skill folders using `SKILL.md`.
4. Link Jira tickets, SharePoint artifacts, and Datadog dashboards in each AI PR.

## Minimum Evidence for AI Release

- Jira ticket (`AI-INIT` or `AI-CHANGE`) with risk level
- SharePoint governance folder with required docs
- Validation report (`Moderate`/`High`)
- ARC approval (`High`)
- Monitoring and alerting setup evidence
- Rollback plan
